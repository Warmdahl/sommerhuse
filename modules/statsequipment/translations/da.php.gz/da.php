<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{statsequipment}prestashop>statsequipment_247270d410e2b9de01814b82111becda'] = 'Browsers og operativsystemer';
$_MODULE['<{statsequipment}prestashop>statsequipment_2876718a648dea03aaafd4b5a63b1efe'] = 'Tilføjer en fane, der indeholder grafer og statistik over brugen af webbrowsere og operativsystemer til dashboardet.';
$_MODULE['<{statsequipment}prestashop>statsequipment_6602bbeb2956c035fb4cb5e844a4861b'] = 'Vejledning';
$_MODULE['<{statsequipment}prestashop>statsequipment_854c8e126f839cc861cde822b641230e'] = 'Sikrer at din hjemmeside er tilgængelig for så mange mennesker som muligt';
$_MODULE['<{statsequipment}prestashop>statsequipment_0d5f13106dec10bb8a9301541052278c'] = 'Når du forvalter en hjemmeside, er det vigtigt at holde styr på den software, der bruges af besøgende, så de er sikre på, at webstedet viser på samme måde for alle. PrestaShop blev bygget til at være kompatibel med de seneste webbrowsere og computer operativsystemer (OS). Men fordi du kan ende med at tilføje avancerede funktioner til din hjemmeside eller endda ændre selve Prestashop koden, er disse tilføjelser muligvis ikke tilgængelig for alle. Derfor er det en god ide at holde styr på procentdelen af brugere for hver type software, før tilføjelse eller ændring af noget som kun et begrænset antal brugere vil kunne få adgang til.';
$_MODULE['<{statsequipment}prestashop>statsequipment_11db1362a88c5e3e74c8f699c14d6798'] = 'Indikerer procentdelen af kundernes anvendte browsere.';
$_MODULE['<{statsequipment}prestashop>statsequipment_998e4c5c80f27dec552e99dfed34889a'] = 'CSV eksport';
$_MODULE['<{statsequipment}prestashop>statsequipment_90c58bfe4872fc9ca7bf6a181c3e5edd'] = 'Indikerer procentdelen af kundernes anvendte operativsystemer.';
$_MODULE['<{statsequipment}prestashop>statsequipment_bb38096ab39160dc20d44f3ea6b44507'] = 'Plug-ins';
$_MODULE['<{statsequipment}prestashop>statsequipment_9ffafc9e090c8e1c06f928ef2817efd6'] = 'Anvendt browser';
$_MODULE['<{statsequipment}prestashop>statsequipment_0241b7aaaa5f76afd585bb6cdae314d1'] = 'Anvendt operativsystem';


return $_MODULE;
