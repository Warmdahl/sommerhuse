<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{bankwire}prestashop>bankwire_05adcee99142c1a60fb38bb1330bbbc1'] = 'التحويل البنكي';
$_MODULE['<{bankwire}prestashop>bankwire_a246a8e9907530c4c36b8b4c37bbc823'] = 'قبول خلاص مشترياتك عبر التحويل البنكي.';
$_MODULE['<{bankwire}prestashop>bankwire_cbe0a99684b145e77f3e14174ac212e3'] = 'هل أنت متأكد أنك تريد حذف البيانات الخاصة بك؟';
$_MODULE['<{bankwire}prestashop>bankwire_0ea0227283d959415eda0cfa31d9f718'] = 'يجب تكوين حساب المالك والتفاصيل من اجل استخدام هذه الوحدة بشكل صحيح.';
$_MODULE['<{bankwire}prestashop>bankwire_a02758d758e8bec77a33d7f392eb3f8a'] = 'لا توجد عملة محددة لهذه الإضافة.';
$_MODULE['<{bankwire}prestashop>bankwire_bfa43217dfe8261ee7cb040339085677'] = 'تفاصيل الحساب مطلوبة.';
$_MODULE['<{bankwire}prestashop>bankwire_ccab155f173ac76f79eb192703f86b18'] = 'مطلوب صاحب الحساب.';
$_MODULE['<{bankwire}prestashop>bankwire_c888438d14855d7d96a2724ee9c306bd'] = 'تم تحديث الإعدادات بنجاح';
$_MODULE['<{bankwire}prestashop>bankwire_5dd532f0a63d89c5af0243b74732f63c'] = 'تفاصيل الاتصال';
$_MODULE['<{bankwire}prestashop>bankwire_857216dd1b374de9bf54068fcd78a8f3'] = 'حساب مالك';
$_MODULE['<{bankwire}prestashop>bankwire_3ec365dd533ddb7ef3d1c111186ce872'] = 'النفاصيل';
$_MODULE['<{bankwire}prestashop>bankwire_6b154cafbab54ba3a1e76a78c290c02a'] = 'مثل فرع البنك ، IBAN رقم ، BIC ، الخ.';
$_MODULE['<{bankwire}prestashop>bankwire_f9a1a1bb716cbae0503d351ea2af4b34'] = 'عنوان البنك';
$_MODULE['<{bankwire}prestashop>bankwire_c9cc8cce247e49bae79f15173ce97354'] = 'حفظ';
$_MODULE['<{bankwire}prestashop>validation_e2b7dec8fa4b498156dfee6e4c84b156'] = 'طريقة الدفع هذه غير متوفرة.';
$_MODULE['<{bankwire}prestashop>payment_execution_6ff063fbc860a79759a7369ac32cee22'] = 'اتمام الطلب';
$_MODULE['<{bankwire}prestashop>payment_execution_f1d3b424cd68795ecaa552883759aceb'] = 'ملخص طلب الشراء';
$_MODULE['<{bankwire}prestashop>payment_execution_879f6b8877752685a966564d072f498f'] = 'سلة الشراء فارغة';
$_MODULE['<{bankwire}prestashop>payment_execution_05adcee99142c1a60fb38bb1330bbbc1'] = 'التحويل البنكي';
$_MODULE['<{bankwire}prestashop>payment_execution_afda466128ee0594745d9f8152699b74'] = 'كنت قد اخترت الدفع بواسطة التحويل البنكي.';
$_MODULE['<{bankwire}prestashop>payment_execution_c884ed19483d45970c5bf23a681e2dd2'] = 'هنا ملخص طلب الشراء:';
$_MODULE['<{bankwire}prestashop>payment_execution_e2867a925cba382f1436d1834bb52a1c'] = 'المبلغ الإجمالي لطلبك';
$_MODULE['<{bankwire}prestashop>payment_execution_1f87346a16cf80c372065de3c54c86d9'] = '(شامل للضريبة)';
$_MODULE['<{bankwire}prestashop>payment_execution_b28be4c423d93e02081f4e79fe2434e8'] = 'نحن نقبل أن تكون ارسلت عدة عملات من خلال التحويل البنكي.';
$_MODULE['<{bankwire}prestashop>payment_execution_a7a08622ee5c8019b57354b99b7693b2'] = 'اختيار واحد من الإجراءات التالية :';
$_MODULE['<{bankwire}prestashop>payment_execution_a854d894458d66d92cabf0411c499ef4'] = 'نحن نقبل العملات التالية ليتم إرسالها بواسطة التحويل البنكي :';
$_MODULE['<{bankwire}prestashop>payment_execution_3dd021316505c0204989f984246c6ff1'] = 'سيتم عرض معلومات الحساب المصرفي في الصفحة التالية.';
$_MODULE['<{bankwire}prestashop>payment_execution_46b9e3665f187c739c55983f757ccda0'] = 'أؤكد طلبي';
$_MODULE['<{bankwire}prestashop>payment_execution_569fd05bdafa1712c4f6be5b153b8418'] = 'طرق الدفع الأخرى';
$_MODULE['<{bankwire}prestashop>infos_c1be305030739396775edaca9813f77d'] = 'هذه الوحدة تسمح لك لقبول المدفوعات عن طريق التحويل البنكي.';
$_MODULE['<{bankwire}prestashop>infos_60742d06006fde3043c77e6549d71a99'] = 'اذا اختار الحريف الدفع بواسطة التحويل البنكي،فإن وضعية الطلب ستتحول الى "في انتظار الدفع"';
$_MODULE['<{bankwire}prestashop>infos_5fb4bbf993c23848433caf58e6b2816d'] = 'لذا، يجب عليك تأكيد الطلب يدوياً حالما تتلقى التحويل البنكي.';
$_MODULE['<{bankwire}prestashop>payment_return_88526efe38fd18179a127024aba8c1d7'] = 'اكتمال طلبك بنسبة %s .';
$_MODULE['<{bankwire}prestashop>payment_return_1f8cdc30326f1f930b0c87b25fdac965'] = 'الرجاء ارسال التحويل البنكي مع:';
$_MODULE['<{bankwire}prestashop>payment_return_b2f40690858b404ed10e62bdf422c704'] = 'الكمية';
$_MODULE['<{bankwire}prestashop>payment_return_5ca0b1b910f393ed1f9f6fa99e414255'] = 'إلى صاحب حساب';
$_MODULE['<{bankwire}prestashop>payment_return_d717aa33e18263b8405ba00e94353cdc'] = 'مع هذه التفاصيل';
$_MODULE['<{bankwire}prestashop>payment_return_984482eb9ff11e6310fef641d2268a2a'] = 'اسم البنك';
$_MODULE['<{bankwire}prestashop>payment_return_1faa25b80a8d31e5ef25a78d3336606d'] = 'لا تنسى ادخال مرجع طلبك %s في خانة الموضوع على ورقة التحويل البنكي.';
$_MODULE['<{bankwire}prestashop>payment_return_19c419a8a4f1cd621853376a930a2e24'] = 'تم ارسال بريد إلكتروني إليك مع هذه المعلومات.';
$_MODULE['<{bankwire}prestashop>payment_return_b9a1cae09e5754424e33764777cfcaa0'] = 'سيتم إرسال طلبك بمجرد استلامنا التسوية الخاصة بك.';
$_MODULE['<{bankwire}prestashop>payment_return_ca7e41a658753c87973936d7ce2429a8'] = 'لأية أسئلة أو لمزيد من المعلومات ، يرجى الاتصال';
$_MODULE['<{bankwire}prestashop>payment_return_d15feee53d81ea16269e54d4784fa123'] = 'لاحظنا مشكلة مع النظام الخاص بك. إذا كنت تعتقد أن هذا خطأ ، يمكنك الاتصال بنا';
$_MODULE['<{bankwire}prestashop>payment_5e1695822fc5af98f6b749ea3cbc9b4c'] = 'الدفع عن طريق التحويل البنكي';
$_MODULE['<{bankwire}prestashop>payment_4e1fb9f4b46556d64db55d50629ee301'] = '(اجراءات الطلب ستكون اطول)';
$_MODULE['<{bankwire}prestashop>payment_return_decce112a9e64363c997b04aa71b7cb8'] = 'دعم العملاء';


return $_MODULE;
