<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{statscatalog}prestashop>statscatalog_cf3aa21c6a2147ddbd86f34091daeccd'] = 'Katalogstatistik';
$_MODULE['<{statscatalog}prestashop>statscatalog_08a7c3cf820979d2c8d4de4f47abb5e6'] = 'Tilføjer et faneblad med generel statistik om dit varekatalog.';
$_MODULE['<{statscatalog}prestashop>statscatalog_74cda5a02df704cc5c3e8fee7fc0f7bc'] = '(1 køb / %d besøg)';
$_MODULE['<{statscatalog}prestashop>statscatalog_0173374ac20f5843d58b553d5b226ef6'] = 'Vælg en kategori';
$_MODULE['<{statscatalog}prestashop>statscatalog_b1c94ca2fbc3e78fc30069c8d0f01680'] = 'Alle';
$_MODULE['<{statscatalog}prestashop>statscatalog_a7b623414d4b6a3225b4e935babec6d2'] = 'Disponible varer:';
$_MODULE['<{statscatalog}prestashop>statscatalog_1099377f1598a0856e2457a5145d89c2'] = 'Gennemsnitspris (grundpris):';
$_MODULE['<{statscatalog}prestashop>statscatalog_48a93dc02c74f3065af1ba47fca070d0'] = 'Varesider set:';
$_MODULE['<{statscatalog}prestashop>statscatalog_156e5c5872c9af24a5c982da07a883c2'] = 'Varer købt:';
$_MODULE['<{statscatalog}prestashop>statscatalog_85f179d4142ca061d49605a7fffdc09d'] = 'Gennemsnitligt antal sider besøgt:';
$_MODULE['<{statscatalog}prestashop>statscatalog_05ff4bfc3baf0acd31a72f1ac754de04'] = 'Gennemsnitligt antal køb:';
$_MODULE['<{statscatalog}prestashop>statscatalog_c09d09e371989d89847049c9574b6b8e'] = 'Disponible billeder:';
$_MODULE['<{statscatalog}prestashop>statscatalog_65275d1b04037d8c8e42425002110363'] = 'Gennemsnitligt antal billeder:';
$_MODULE['<{statscatalog}prestashop>statscatalog_51b8891d531ad91128ba58c8928322ab'] = 'Varer aldrig set:';
$_MODULE['<{statscatalog}prestashop>statscatalog_8725647ef741e5d48c1e6f652ce80b50'] = 'Varer aldrig købt:';
$_MODULE['<{statscatalog}prestashop>statscatalog_b86770bc713186bcf43dbb1164c5fd28'] = 'Konverteringsgrad*:';
$_MODULE['<{statscatalog}prestashop>statscatalog_082d537edb8c61539b9f266eb331c88e'] = 'Gennemsnitlig konvertering for denne vareside. Det er muligt at købe en vare uden at se varen, så forholdet kan være større end 1.';
$_MODULE['<{statscatalog}prestashop>statscatalog_58a714d3e9bb2902a5b688c99bd4d8e6'] = 'Varer aldrig købt';
$_MODULE['<{statscatalog}prestashop>statscatalog_b718adec73e04ce3ec720dd11a06a308'] = 'ID';
$_MODULE['<{statscatalog}prestashop>statscatalog_49ee3087348e8d44e1feda1917443987'] = 'Navn';
$_MODULE['<{statscatalog}prestashop>statscatalog_8e7c9a35104a5a68199678bd6bc5d187'] = 'Rediger / Se';
$_MODULE['<{statscatalog}prestashop>statscatalog_7dce122004969d56ae2e0245cb754d35'] = 'Rediger';
$_MODULE['<{statscatalog}prestashop>statscatalog_4351cfebe4b61d8aa5efa1d020710005'] = 'Vis';


return $_MODULE;
