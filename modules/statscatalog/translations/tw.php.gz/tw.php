<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{statscatalog}prestashop>statscatalog_cf3aa21c6a2147ddbd86f34091daeccd'] = '目錄統計';
$_MODULE['<{statscatalog}prestashop>statscatalog_08a7c3cf820979d2c8d4de4f47abb5e6'] = '在儀錶盤添加包含有關您目錄的一般統計標籤。';
$_MODULE['<{statscatalog}prestashop>statscatalog_74cda5a02df704cc5c3e8fee7fc0f7bc'] = '(1 個訂單 / %d 訪問次數)';
$_MODULE['<{statscatalog}prestashop>statscatalog_0173374ac20f5843d58b553d5b226ef6'] = '選擇一個分類';
$_MODULE['<{statscatalog}prestashop>statscatalog_b1c94ca2fbc3e78fc30069c8d0f01680'] = '全部';
$_MODULE['<{statscatalog}prestashop>statscatalog_a7b623414d4b6a3225b4e935babec6d2'] = '可購產品：';
$_MODULE['<{statscatalog}prestashop>statscatalog_1099377f1598a0856e2457a5145d89c2'] = '平均價格（基礎價格）：';
$_MODULE['<{statscatalog}prestashop>statscatalog_48a93dc02c74f3065af1ba47fca070d0'] = '已瀏覽產品頁面：';
$_MODULE['<{statscatalog}prestashop>statscatalog_156e5c5872c9af24a5c982da07a883c2'] = '被購產品：';
$_MODULE['<{statscatalog}prestashop>statscatalog_85f179d4142ca061d49605a7fffdc09d'] = '平均頁面訪問：';
$_MODULE['<{statscatalog}prestashop>statscatalog_05ff4bfc3baf0acd31a72f1ac754de04'] = '平均購買：';
$_MODULE['<{statscatalog}prestashop>statscatalog_c09d09e371989d89847049c9574b6b8e'] = '可用圖片：';
$_MODULE['<{statscatalog}prestashop>statscatalog_65275d1b04037d8c8e42425002110363'] = '平均圖片數：';
$_MODULE['<{statscatalog}prestashop>statscatalog_51b8891d531ad91128ba58c8928322ab'] = '從未被查看的產品：';
$_MODULE['<{statscatalog}prestashop>statscatalog_8725647ef741e5d48c1e6f652ce80b50'] = '產品永不購買：';
$_MODULE['<{statscatalog}prestashop>statscatalog_b86770bc713186bcf43dbb1164c5fd28'] = '調價*：';
$_MODULE['<{statscatalog}prestashop>statscatalog_082d537edb8c61539b9f266eb331c88e'] = '設定商品頁平均轉換率（因為訂購產品有可能沒有瀏覽產品頁，所以這個比率可以大於 1）';
$_MODULE['<{statscatalog}prestashop>statscatalog_58a714d3e9bb2902a5b688c99bd4d8e6'] = '產品永不購買';
$_MODULE['<{statscatalog}prestashop>statscatalog_b718adec73e04ce3ec720dd11a06a308'] = '編號';
$_MODULE['<{statscatalog}prestashop>statscatalog_49ee3087348e8d44e1feda1917443987'] = '名稱';
$_MODULE['<{statscatalog}prestashop>statscatalog_8e7c9a35104a5a68199678bd6bc5d187'] = '編輯/查看';
$_MODULE['<{statscatalog}prestashop>statscatalog_7dce122004969d56ae2e0245cb754d35'] = '編輯';
$_MODULE['<{statscatalog}prestashop>statscatalog_4351cfebe4b61d8aa5efa1d020710005'] = '瀏覽';


return $_MODULE;
